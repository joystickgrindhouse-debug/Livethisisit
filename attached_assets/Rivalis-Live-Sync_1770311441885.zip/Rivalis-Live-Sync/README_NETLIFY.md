# Rivalis Live Mode (PWA)

## Deployment Checklist for Netlify

This project is configured as a Single Page Application (SPA) PWA. It requires no server-side backend logic for hosting, but relies on Firebase for auth/data.

### 1. Build Command
- **Build command:** `npm run build`
- **Publish directory:** `dist/public`

### 2. Environment Variables (REQUIRED)
Ensure these are set in the Netlify UI (Site Settings > Environment Variables). The app WILL NOT LOAD without them.

| Variable | Description |
|---|---|
| `VITE_FIREBASE_API_KEY` | Firebase API Key |
| `VITE_FIREBASE_AUTH_DOMAIN` | Firebase Auth Domain |
| `VITE_FIREBASE_PROJECT_ID` | Firebase Project ID |
| `VITE_FIREBASE_STORAGE_BUCKET` | Storage Bucket |
| `VITE_FIREBASE_MESSAGING_SENDER_ID` | Messaging Sender ID |
| `VITE_FIREBASE_APP_ID` | App ID |
| `VITE_FIREBASE_MEASUREMENT_ID` | (Optional) Measurement ID |

### 3. Verification Steps
After deployment:
1. Open the URL on a mobile device.
2. Verify the "Install App" prompt appears or "Add to Home Screen" works.
3. Refresh the page on a deep link like `/room/LOBBY` to verify SPA routing (controlled by `netlify.toml`).
4. Check Chrome DevTools > Application > Service Workers to ensure `sw.js` is active.
5. **Critical:** Verify you can create a room. If it fails or spins forever, check the JS console for Firestore permission errors (requires Firestore rules allowing read/write).

### 4. Firestore Rules (Reference)
Ensure your Firebase console has rules that allow reads/writes for authenticated users (including anonymous):

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /rooms/{roomId} {
      allow read, write: if request.auth != null;
    }
  }
}
```
