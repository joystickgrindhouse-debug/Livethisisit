export interface Player {
  id: string;
  name: string;
  avatar?: string;
  ready: boolean;
  score: number;
  isHost: boolean;
  isBot?: boolean;
  status: 'idle' | 'active' | 'eliminated';
}

export interface Room {
  code: string;
  hostId: string;
  players: Player[];
  status: 'lobby' | 'starting' | 'in-game' | 'finished';
  isPublic: boolean;
  settings: GameSettings;
  gameState?: GameState; // Added to sync via Firestore
}

export type FocusArea = 'arms' | 'legs' | 'core' | 'total';

export interface GameSettings {
  burnoutType: 'classic' | 'pyramid' | 'sudden-death' | 'time-attack';
  focusArea: FocusArea;
  roundTime: number; // in seconds
  rounds: number;
  restTime: number;
}

export interface Exercise {
  id: string;
  name: string;
  type: 'rep' | 'hold';
  focus: FocusArea[];
  thresholds: {
    beginner: number;
    intermediate: number;
    advanced: number;
    elite: number;
  };
}

export type CardType = 'trick' | 'joker';

export interface GameCard {
  id: string;
  type: CardType;
  name: string;
  description: string;
  effect: 'double-points' | 'half-reps' | 'add-reps' | 'skip' | 'freeze' | 'blind';
  target: 'self' | 'others' | 'all';
  icon: string;
}

export interface GameState {
  currentRound: number;
  currentExerciseIndex: number;
  timeRemaining: number;
  activeCard: GameCard | null;
  exercises: Exercise[];
}
