import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export function GameLayout({ children, className }: { children: React.ReactNode, className?: string }) {
  return (
    <div className="min-h-screen w-full bg-background text-foreground overflow-hidden relative selection:bg-primary selection:text-black">
      {/* Background Elements */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-black/80 z-10" /> {/* Dark overlay */}
        <img 
            src="/assets/background-athletic.png" 
            alt="Background" 
            className="absolute inset-0 w-full h-full object-cover opacity-40 grayscale mix-blend-overlay"
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/5 via-background to-background z-20" />
        <div className="absolute inset-0 bg-grid-pattern opacity-10 z-20" />
      </div>
      
      {/* Scanline Effect */}
      <div className="fixed inset-0 z-50 pointer-events-none opacity-5 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]" />

      <main className={cn("relative z-30 flex flex-col h-screen", className)}>
        {children}
      </main>
    </div>
  );
}
