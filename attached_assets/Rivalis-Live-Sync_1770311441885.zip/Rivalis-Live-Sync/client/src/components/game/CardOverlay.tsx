import { useGameStore } from "@/lib/store";
import { GameCard } from "@/lib/types";
import { motion, AnimatePresence } from "framer-motion";
import { ShieldAlert, Zap, Clock, TrendingUp, RefreshCcw, Hand } from "lucide-react";

export function CardOverlay() {
  const activeCard = useGameStore((state) => state.gameState?.activeCard);

  return (
    <AnimatePresence>
      {activeCard && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.8, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 1.1, y: -50 }}
          className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none p-4"
        >
          <div className="bg-black/80 backdrop-blur-md border-2 border-primary p-8 rounded-xl max-w-sm w-full text-center relative overflow-hidden box-shadow-neon">
            <div className="absolute inset-0 bg-primary/10 animate-pulse" />
            
            <motion.div 
              initial={{ rotate: -10 }} 
              animate={{ rotate: 0 }}
              className="mb-4 inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary text-black"
            >
              {getIcon(activeCard.icon)}
            </motion.div>
            
            <h2 className="text-3xl font-display text-primary mb-2 uppercase tracking-widest">{activeCard.name}</h2>
            <p className="text-xl text-white font-ui">{activeCard.description}</p>
            
            <div className="mt-6 text-sm text-primary/70 uppercase tracking-widest">
              Effect Active
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function getIcon(name: string) {
  switch(name) {
    case 'zap': return <Zap size={40} />;
    case 'shield': return <ShieldAlert size={40} />;
    case 'clock': return <Clock size={40} />;
    case 'trending-up': return <TrendingUp size={40} />;
    case 'refresh': return <RefreshCcw size={40} />;
    default: return <Hand size={40} />;
  }
}

export const MOCK_DECK: GameCard[] = [
  { id: 'c1', type: 'trick', name: 'Double Down', description: 'Next rep counts as 2x!', effect: 'double-points', target: 'self', icon: 'trending-up' },
  { id: 'c2', type: 'trick', name: 'Freeze', description: 'Opponents freeze for 3s!', effect: 'freeze', target: 'others', icon: 'shield' },
  { id: 'c3', type: 'joker', name: 'Wildcard', description: 'Instant 10 Reps!', effect: 'add-reps', target: 'self', icon: 'zap' },
];
