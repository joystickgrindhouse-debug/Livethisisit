import { useEffect, useState } from "react";
import { useGameStore } from "@/lib/store";
import { checkFirebaseConfig } from "@/lib/firebase";
import { useLocation } from "wouter";
import { AlertTriangle, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { user, initializeAuth, loading, error } = useGameStore();
  const [configValid, setConfigValid] = useState(true);

  useEffect(() => {
    if (!checkFirebaseConfig()) {
      setConfigValid(false);
      return;
    }
    const unsubscribe = initializeAuth();
    return () => unsubscribe();
  }, []);

  if (!configValid) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-black text-white p-6 text-center">
        <AlertTriangle className="text-destructive w-16 h-16 mb-4" />
        <h1 className="text-2xl font-bold mb-2">Configuration Error</h1>
        <p className="text-muted-foreground mb-6">Firebase environment variables are missing.</p>
        <p className="text-sm font-mono bg-secondary/50 p-4 rounded text-left">
           VITE_FIREBASE_API_KEY<br/>
           VITE_FIREBASE_AUTH_DOMAIN<br/>
           VITE_FIREBASE_PROJECT_ID<br/>
           ...
        </p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-foreground">
        <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs uppercase tracking-widest animate-pulse">Connecting to Rivalis Network...</p>
        </div>
      </div>
    );
  }

  if (error) {
     return (
        <div className="flex h-screen items-center justify-center bg-background text-foreground flex-col gap-4">
            <WifiOff size={48} className="text-muted-foreground" />
            <p className="text-destructive">{error}</p>
            <Button onClick={() => window.location.reload()} variant="outline">Retry</Button>
        </div>
     );
  }

  if (!user) {
     // Auth init should handle auto-anon login, so this state is transient
     return null;
  }

  return <>{children}</>;
}
