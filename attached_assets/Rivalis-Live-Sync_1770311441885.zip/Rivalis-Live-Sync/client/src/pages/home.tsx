import { useState } from "react";
import { useGameStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { burnoutTypes, focusAreas } from "@/lib/exercises";
import { Users, Play, Crown, Globe, Lock, Dumbbell, Zap } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

export default function Home() {
  const [_, setLocation] = useLocation();
  const [roomCode, setRoomCode] = useState("");
  const { createRoom, joinRoom, joinPublicMatch, user } = useGameStore();
  const [selectedFocus, setSelectedFocus] = useState(focusAreas[3].id);
  const [selectedMode, setSelectedMode] = useState(burnoutTypes[0].id);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleCreatePrivate = async () => {
    await createRoom(selectedFocus as any, selectedMode as any, false);
    setLocation("/room/lobby");
  };

  const handleJoinPrivate = async () => {
    if (await joinRoom(roomCode.toUpperCase())) {
      setLocation(`/room/${roomCode.toUpperCase()}`);
    } else {
      alert("Room not found or full");
    }
  };

  const handlePublicMatch = async () => {
    await joinPublicMatch(selectedFocus as any, selectedMode as any);
    setLocation("/room/lobby");
  };

  const ModeSelector = () => (
    <div className="space-y-6">
      <div className="space-y-2">
         <div className="text-xs text-muted-foreground uppercase tracking-wider font-bold">1. Select Focus Area</div>
         <div className="grid grid-cols-2 gap-2">
            {focusAreas.map((area) => (
              <button
                key={area.id}
                onClick={() => setSelectedFocus(area.id)}
                className={cn(
                  "p-4 rounded-md text-center transition-all border relative overflow-hidden group",
                  selectedFocus === area.id 
                    ? "bg-primary text-black border-primary shadow-[0_0_15px_rgba(255,0,0,0.4)]" 
                    : "bg-black/40 border-white/10 text-muted-foreground hover:bg-white/5 hover:border-white/30"
                )}
              >
                <div className="relative z-10 font-black text-sm uppercase tracking-wider">{area.name}</div>
                {selectedFocus === area.id && (
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none" />
                )}
              </button>
            ))}
          </div>
      </div>

      <div className="space-y-2">
          <button 
             onClick={() => setShowAdvanced(!showAdvanced)}
             className="text-xs text-primary uppercase tracking-wider font-bold flex items-center gap-1 hover:underline"
          >
             <Zap size={12} /> 2. {showAdvanced ? 'Hide' : 'Show'} Advanced Modes
          </button>
          
          {showAdvanced && (
             <div className="grid grid-cols-2 gap-2 animate-in slide-in-from-top-2 fade-in duration-300">
                {burnoutTypes.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => setSelectedMode(type.id)}
                    className={cn(
                      "p-3 rounded-md text-left transition-all border",
                      selectedMode === type.id 
                        ? "bg-white/10 border-white text-white" 
                        : "bg-black/20 border-transparent text-muted-foreground hover:bg-white/5"
                    )}
                  >
                    <div className="font-bold text-[10px] uppercase">{type.name}</div>
                  </button>
                ))}
              </div>
          )}
          {!showAdvanced && (
              <div className="text-[10px] text-muted-foreground italic">Default: Classic Burnout</div>
          )}
      </div>
    </div>
  );

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-6 max-w-md mx-auto w-full relative">
      <div className="text-center mb-8 relative z-10">
        <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-primary mb-2 tracking-tighter filter drop-shadow-[0_0_10px_rgba(255,0,0,0.8)]">
          RIVALIS
        </h1>
        <p className="text-xl text-primary font-ui uppercase tracking-[0.5em] text-shadow-neon">Live Mode</p>
      </div>

      <div className="w-full space-y-6 relative z-10">
        <Tabs defaultValue="public" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4 bg-black/60 backdrop-blur-md border border-white/10 p-1">
            <TabsTrigger value="public" className="font-display uppercase tracking-wider data-[state=active]:bg-primary data-[state=active]:text-black transition-all duration-300">
              <Globe size={16} className="mr-2" /> Public
            </TabsTrigger>
            <TabsTrigger value="private" className="font-display uppercase tracking-wider data-[state=active]:bg-primary data-[state=active]:text-black transition-all duration-300">
              <Lock size={16} className="mr-2" /> Private
            </TabsTrigger>
          </TabsList>

          <TabsContent value="public">
            <Card className="p-6 bg-black/60 border-primary/30 backdrop-blur-md space-y-6 shadow-[0_0_30px_rgba(0,0,0,0.5)]">
               <div className="text-center">
                  <h2 className="text-lg font-display text-primary mb-1 tracking-widest uppercase">Find Match</h2>
                  <p className="text-xs text-muted-foreground">Ranked matchmaking • Open lobby</p>
               </div>
               
               <ModeSelector />

               <Button onClick={handlePublicMatch} className="w-full bg-primary text-black hover:bg-white hover:text-primary transition-colors font-black text-lg uppercase tracking-widest py-8 shadow-[0_0_20px_rgba(255,0,0,0.4)] animate-pulse border-2 border-transparent hover:border-primary">
                  Start Search
               </Button>
            </Card>
          </TabsContent>

          <TabsContent value="private">
            <div className="space-y-4">
              <Card className="p-6 bg-black/60 border-white/10 backdrop-blur-md">
                <h2 className="text-lg font-display text-white mb-4 flex items-center gap-2">
                  <Crown size={20} className="text-primary" /> Host Private
                </h2>
                
                <ModeSelector />

                <Button onClick={handleCreatePrivate} variant="secondary" className="w-full font-bold uppercase tracking-wider py-6 mt-6 border border-white/10 hover:border-primary hover:text-primary">
                  Create Lobby
                </Button>
              </Card>

              <div className="relative flex items-center justify-center my-4">
                <div className="h-px bg-white/10 w-full"></div>
                <span className="absolute bg-black px-2 text-muted-foreground text-xs uppercase">Or</span>
              </div>

              <Card className="p-6 bg-black/60 border-white/10 backdrop-blur-md">
                <h2 className="text-lg font-display text-white mb-4 flex items-center gap-2">
                  <Users size={20} className="text-primary" /> Join Private
                </h2>
                <div className="flex gap-2">
                  <Input 
                    placeholder="ENTER CODE" 
                    value={roomCode}
                    onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                    className="bg-black/40 border-white/10 font-mono text-center uppercase tracking-widest text-lg focus:border-primary focus:ring-primary/50"
                    maxLength={6}
                  />
                  <Button onClick={handleJoinPrivate} variant="outline" className="border-white/20 hover:bg-white/10 hover:text-primary hover:border-primary">
                    <Play size={20} />
                  </Button>
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <div className="mt-8 text-center relative z-10">
        <p className="text-xs text-muted-foreground font-mono">
          Logged in as <span className="text-primary font-bold">{user?.name}</span>
        </p>
      </div>
    </div>
  );
}
